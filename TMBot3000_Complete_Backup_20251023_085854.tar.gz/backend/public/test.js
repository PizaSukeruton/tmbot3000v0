function testFunction() { alert("External JS working perfectly!"); }
