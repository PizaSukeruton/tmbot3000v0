
// === DEBUG: Filter result in MessageProcessor ===
console.log('[DEBUG] Filter result received in MessageProcessor:', JSON.stringify(filterResult, null, 2));
// === END DEBUG ===
